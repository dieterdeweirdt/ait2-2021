<?php

class Article extends BaseModel {

    protected $table = 'articles';
    protected $pk = 'id';

}