<h1><?= $current_page->title; ?></h1>
<?= $current_page->content; ?>

HIER MOETEN NOG PROJECTEN KOMEN