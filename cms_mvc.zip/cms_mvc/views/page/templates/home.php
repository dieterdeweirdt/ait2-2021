<img src="images/home.png" alt="Graduaat programmeren">
<h1><?= $current_page->title; ?></h1>
<?= $current_page->content; ?>