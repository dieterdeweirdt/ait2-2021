<h1>Index pagina van de articles</h1>
<?php


print_r( $articles );