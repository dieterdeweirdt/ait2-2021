<h1>Detail pagina van een article</h1>

<?php


print_r( $article );